export interface Bid {
  id: number;
  status: 'Active' | 'Closed';
  bidCount: number;
  currentPrice: number;
  endTime: string;
  name: string;
}

export interface Activity {
  user: string;
  action: string;
  bid: string;
  time: string;
}

export interface LeaderboardUser {
  rank: number;
  userName: string;
  points: number;
  avatar: string;
  badges: number;
}

export type PageType = 'home' | 'bids' | 'leaderboard';