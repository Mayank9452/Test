import type { Bid, Activity, LeaderboardUser } from '../types';

export const BIDS_DATA: Bid[] = [
  { id: 1, status: 'Active', bidCount: 12, currentPrice: 1250, endTime: '2h : 15m : 50s', name: 'Bid 1' },
  { id: 2, status: 'Active', bidCount: 8, currentPrice: 890, endTime: '5h : 30m : 10s', name: 'Bid 2' },
  { id: 3, status: 'Closed', bidCount: 24, currentPrice: 2100, endTime: 'Ended', name: 'Bid 3' },
  { id: 4, status: 'Active', bidCount: 15, currentPrice: 1580, endTime: '1h : 45m : 25s', name: 'Bid 4' },
];

export const ACTIVITY_FEED: Activity[] = [
  { user: 'Sumit Kumar', action: 'joined', bid: 'Bid 1', time: '2m ago' },
  { user: 'Ajay Patel', action: 'placed bid on', bid: 'Bid 3', time: '5m ago' },
  { user: 'Priya Sharma', action: 'won', bid: 'Bid 2', time: '8m ago' },
  { user: 'Rahul Verma', action: 'joined', bid: 'Bid 4', time: '12m ago' },
  { user: 'Neha Singh', action: 'placed bid on', bid: 'Bid 1', time: '15m ago' },
  { user: 'Vikram Shah', action: 'joined', bid: 'Bid 3', time: '18m ago' }
];

export const LEADERBOARD_DATA: LeaderboardUser[] = [
  { rank: 1, userName: 'Sumit Kumar', points: 2450, avatar: '🏆', badges: 12 },
  { rank: 2, userName: 'Priya Sharma', points: 2180, avatar: '🥈', badges: 10 },
  { rank: 3, userName: 'Ajay Patel', points: 1950, avatar: '🥉', badges: 8 },
  { rank: 4, userName: 'Neha Singh', points: 1720, avatar: '⭐', badges: 6 },
  // { rank: 5, userName: 'Rahul Verma', points: 1580, avatar: '⭐', badges: 5 }
];