// import React from 'react';
// import { Card } from 'react-bootstrap';
// import { FaChartLine } from 'react-icons/fa';
// import type { Activity } from '../types';

// interface ActivitySliderProps {
//   activities: Activity[];
// }

// const ActivitySlider: React.FC<ActivitySliderProps> = ({ activities }) => {
//   const tripleActivities = [...activities, ...activities, ...activities];

//   return (
//     <Card className="shadow">
//       <Card.Header className="bg-primary text-white">
//         <div className="d-flex align-items-center">
//           <FaChartLine className="me-2" />
//           <strong>Live Activity Feed</strong>
//         </div>
//       </Card.Header>
//       <Card.Body className="p-0">
//         <div className="activity-marquee">
//           <div className="activity-scroll">
//             {tripleActivities.map((activity, idx) => (
//               <div key={idx} className="activity-item">
//                 <span className="text-white fw-bold me-2">{activity.user}</span>
//                 <span className="text-white opacity-75 me-2">{activity.action}</span>
//                 <span className="text-warning fw-bold me-2">{activity.bid}</span>
//                 <span className="text-white-50 small">{activity.time}</span>
//               </div>
//             ))}
//           </div>
//         </div>
//       </Card.Body>
//     </Card>
//   );
// };

// export default ActivitySlider;


import type { Activity } from "../types";

interface ActivitySliderProps {
  activities: Activity[];
}

const ActivitySlider: React.FC<ActivitySliderProps> = ({ activities }) => {
  return (
    <div className="activity-wrapper">
      <div className="activity-track">
        {[...activities, ...activities].map((activity, index) => (
          <div className="activity-pill" key={index}>
            <strong>{activity.user}</strong>&nbsp;
            {activity.action}&nbsp;
            <span className="text-primary">{activity.bid}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivitySlider;
