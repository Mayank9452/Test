// ==================== src/components/Leaderboard.tsx ====================
import React from 'react';
import { Card, Table, Badge } from 'react-bootstrap';
import { FaTrophy, FaAward } from 'react-icons/fa';
import type { LeaderboardUser } from '../types';

interface LeaderboardProps {
  users: LeaderboardUser[];
  showTitle?: boolean;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ users, showTitle = true }) => {
  return (
    <Card className="shadow">
      {showTitle && (
        <Card.Header className="bg-primary text-white text-center py-3"
        style={{background: "linear-gradient(135deg, rgb(102, 126, 234) 0%, rgb(118, 75, 162) 100%)"}}
        >
          <h3 className="mb-0">
            <FaTrophy className="me-2" />
            Top Bidders
          </h3>
        </Card.Header>
      )}
      <Card.Body className="p-0">
        <Table striped hover responsive className="mb-0">
          <thead className="table-light">
            <tr>
              <th>Rank</th>
              <th>User</th>
              {/* <th>Badges</th> */}
              {/* <th className="text-end">Points</th> */}
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.rank} style={{ cursor: 'pointer' }}>
                <td>
                  <div className="d-flex align-items-center">
                    <span style={{ fontSize: '2rem', marginRight: '0.5rem' }}>
                      {user.avatar}
                    </span>
                    <strong>#{user.rank}</strong>
                  </div>
                </td>
                <td>
                  <div>
                    <strong>{user.userName}</strong>
                    <br />
                    <small className="text-muted">
                      {user.rank === 1 ? 'Champion' : user.rank === 2 ? 'Runner-up' : 'Top Bidder'}
                    </small>
                  </div>
                </td>
                {/* <td>
                  <Badge bg="info">
                    <FaAward className="me-1" />
                    {user.badges}
                  </Badge>
                </td> */}
                {/* <td className="text-end">
                  <strong className="text-primary fs-5">{user.points.toLocaleString()}</strong>
                  <br />
                  <small className="text-muted">points</small>
                </td> */}
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  );
};

export default Leaderboard;


// import { Card } from "react-bootstrap";
// import type { LeaderboardUser } from "../types";

// interface LeaderboardProps {
//   users: LeaderboardUser[];
//   showTitle?: boolean;
// }

// const Leaderboard: React.FC<LeaderboardProps> = ({
//   users,
//   showTitle = true,
// }) => {
//   return (
//     <div className="leaderboard">
//       {showTitle && <h5 className="fw-bold mb-3">🏆 Leaderboard</h5>}

//       {users.map((user) => (
//         <Card key={user.rank} className="leaderboard-card mb-2">
//           <Card.Body className="p-2 d-flex align-items-center">
//             <div className="rank-badge">{user.rank}</div>

//             <div className="avatar">{user.avatar}</div>

//             <div className="flex-grow-1">
//               <div className="fw-semibold">{user.userName}</div>
//               <small className="text-muted">
//                 {user.points} pts • {user.badges} badges
//               </small>
//             </div>
//           </Card.Body>
//         </Card>
//       ))}
//     </div>
//   );
// };

// export default Leaderboard;
