// import React from 'react';
// import { Card, Button, Badge } from 'react-bootstrap';
// import { FaUsers, FaClock } from 'react-icons/fa';
// import type { Bid } from '../types';

// interface BidCardProps {
//   bid: Bid;
//   onEnterBid?: (bidId: number) => void;
// }

// const BidCard: React.FC<BidCardProps> = ({ bid, onEnterBid }) => {
//   return (
//     <Card className="bid-card shadow h-100">
//       <Card.Header 
//         className={bid.status === 'Active' ? 'bg-success text-white' : 'bg-secondary text-white'}
//       >
//         <div className="d-flex justify-content-between align-items-center">
//           <h5 className="mb-0 fw-bold">Bid {bid.id}</h5>
//           <Badge bg="light" text="dark">
//             {bid.status}
//           </Badge>
//         </div>
//       </Card.Header>
//       <Card.Body>
//         <div className="mb-3">
//           <div className="d-flex align-items-center text-muted mb-2">
//             <FaUsers className="me-2" />
//             <span>{bid.bidCount} participants</span>
//           </div>
//           <div className="d-flex align-items-center text-muted mb-2">
//             <FaClock className="me-2" />
//             <span>Ends in: {bid.endTime}</span>
//           </div>
//         </div>
        
//         <div className="mb-3">
//           <Badge bg="warning" text="dark" className="fs-5 fw-bold">
//             ₹{bid.currentPrice.toLocaleString()}
//           </Badge>
//           <small className="text-muted ms-2">Current Price</small>
//         </div>

//         <Card.Text className="text-muted">
//           {bid.status === 'Active' 
//             ? 'Join now and start bidding to win!' 
//             : 'This bidding has ended'}
//         </Card.Text>

//         <Button 
//           variant={bid.status === 'Active' ? 'primary' : 'secondary'}
//           disabled={bid.status !== 'Active'}
//           onClick={() => onEnterBid?.(bid.id)}
//           className="w-100"
//           size="lg"
//         >
//           {bid.status === 'Active' ? 'Enter Bidding' : 'Closed'}
//         </Button>
//       </Card.Body>
//     </Card>
//   );
// };

// export default BidCard;

import { Card, Badge, Button } from "react-bootstrap";
import { FaClock, FaUsers } from "react-icons/fa";
import type { Bid } from "../types";

interface BidCardProps {
  bid: Bid;
  onEnterBid?: (id: number) => void;
}

const BidCard: React.FC<BidCardProps> = ({ bid, onEnterBid }) => {
  const isActive = bid.status === "Active";

  return (
    <Card className="bid-card h-100">
      <Card.Body className="p-2 d-flex flex-column">
        {/* Status */}
        <div className="d-flex justify-content-between align-items-center mb-2">
          <Badge className={isActive ? "badge-active" : "badge-closed"}>
            {bid.status}
          </Badge>
          {/* <span className="bid-id">#{bid.id}</span> */}
        </div>

        {/* Price */}
        <div className="price-section mb-2">
          {/* <span className="currency">₹</span>
          <span className="price">{bid.currentPrice}</span> */}
          
          <span className="price">{bid.name}</span>
        </div>

        {/* Meta Info */}
        <div className="meta-info mb-3">
          <div className="meta-item">
            <FaUsers size={14} />
            <span>{bid.bidCount} bidders</span>
          </div>
          <div className="meta-item">
            <FaClock size={14} />
            <span>{bid.endTime}</span>
          </div>
        </div>

        {/* CTA */}
        <Button
          disabled={!isActive}
          onClick={() => onEnterBid?.(bid.id)}
          className={`bid-btn mt-auto ${
            isActive ? "btn-active" : "btn-closed"
          }`}
        >
          {isActive ? "Enter Bid" : "Closed"}
        </Button>
      </Card.Body>
    </Card>
  );
};

export default BidCard;
