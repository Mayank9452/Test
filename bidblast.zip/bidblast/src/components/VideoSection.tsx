// import React from 'react';
// import { Card } from 'react-bootstrap';
// import { FaPlay } from 'react-icons/fa';

// interface VideoSectionProps {
//   videoUrl?: string;
//   title?: string;
//   description?: string;
// }

// const VideoSection: React.FC<VideoSectionProps> = ({ 
//   videoUrl, 
//   title = 'How Bidding Works',
//   description = 'Watch our tutorial video'
// }) => {
//   return (
//     <Card className="shadow">
//       <Card.Body className="p-0">
//         {videoUrl ? (
//           <div style={{ aspectRatio: '16/9' }}>
//             <iframe
//               src={videoUrl}
//               style={{ width: '100%', height: '100%' }}
//               allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
//               allowFullScreen
//               title={title}
//             />
//           </div>
//         ) : (
//           <div 
//             style={{ 
//               background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
//               height: '400px',
//               display: 'flex',
//               alignItems: 'center',
//               justifyContent: 'center',
//               cursor: 'pointer',
//               transition: 'transform 0.3s ease'
//             }}
//             onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.02)'}
//             onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
//           >
//             <div className="text-center text-white">
//               <div 
//                 className="mb-3 mx-auto"
//                 style={{
//                   width: '100px',
//                   height: '100px',
//                   background: 'rgba(255, 255, 255, 0.3)',
//                   borderRadius: '50%',
//                   display: 'flex',
//                   alignItems: 'center',
//                   justifyContent: 'center',
//                   backdropFilter: 'blur(10px)'
//                 }}
//               >
//                 <FaPlay size={40} />
//               </div>
//               <h4 className="mb-2">{title}</h4>
//               <p className="mb-0">{description}</p>
//             </div>
//           </div>
//         )}
//       </Card.Body>
//     </Card>
//   );
// };

// export default VideoSection;

import { Card } from "react-bootstrap";
import { FaPlay } from "react-icons/fa";

interface VideoSectionProps {
  title?: string;
  description?: string;
  videoUrl?: string;
}

const VideoSection: React.FC<VideoSectionProps> = ({
  title = 'How Bidding Works',
  description = 'Watch our Bidding video',
  videoUrl,
}) => {
  return (
    <Card className="video-card">
      <div className="video-thumb">
        <div className="play-btn">
          <FaPlay />
        </div>
      </div>

      <Card.Body className="p-3">
        <h6 className="fw-bold mb-1">{title}</h6>
        <p className="text-muted small mb-0">{description}</p>
      </Card.Body>
    </Card>
  );
};

export default VideoSection;
