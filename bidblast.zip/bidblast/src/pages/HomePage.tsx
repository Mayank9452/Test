// ==================== src/pages/HomePage.tsx ====================
import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { FaTrophy, FaUsers, FaStar } from 'react-icons/fa';
import BidCard from '../components/BidCard';
import VideoSection from '../components/VideoSection';
import ActivitySlider from '../components/ActivitySlider';
import Leaderboard from '../components/Leaderboard';
import { BIDS_DATA, ACTIVITY_FEED, LEADERBOARD_DATA } from '../utils/mockData';
import HeroSection from '../components/HeroSection';
import StatsCards from '../components/StatsCards';

const HomePage: React.FC = () => {
  const handleEnterBid = (bidId: number) => {
    alert(`You're entering Bid ${bidId}! Good luck! 🎯`);
  };

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <div
        className="text-center text-white p-4 mb-4 rounded shadow"
        style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}
      >
        <h1 className="display-6 fw-bold mb-3">Welcome to BidMaster</h1>
        <p className="fs-12">Join active bids and compete to win amazing prizes!</p>
      </div>

      <HeroSection />
      <StatsCards />

      {/* Stats Cards */}
      {/* <Row className="mb-5 g-4">
        <Col md={4}>
          <Card className="text-center shadow border-0 h-100">
            <Card.Body className="py-4">
              <FaTrophy size={48} className="text-warning mb-3" />
              <h3 className="fw-bold">156</h3>
              <p className="text-muted mb-0">Active Bids</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="text-center shadow border-0 h-100">
            <Card.Body className="py-4">
              <FaUsers size={48} className="text-primary mb-3" />
              <h3 className="fw-bold">2.4K</h3>
              <p className="text-muted mb-0">Active Users</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="text-center shadow border-0 h-100">
            <Card.Body className="py-4">
              <FaStar size={48} className="text-success mb-3" />
              <h3 className="fw-bold">₹15L</h3>
              <p className="text-muted mb-0">Prize Pool</p>
            </Card.Body>
          </Card>
        </Col>
      </Row> */}

      {/* Active Bids */}
      <h4 className="fw-bold text-center mb-4">Active Bids</h4>
      <Row className="g-3 mb-5">
        {BIDS_DATA.map((bid) => (
          <Col key={bid.id} xs={6} sm={6} md={4} lg={3}>
            <BidCard bid={bid} />
          </Col>
        ))}
      </Row>

      {/* Video Section */}
      <h4 className="fw-bold text-center mb-4">How It Works</h4>
      <div className="mb-4">
        <VideoSection />
      </div>

      {/* Activity Feed */}
      <h4 className="fw-bold text-center mb-4">Live Activity</h4>
      <div className="mb-4">
        <ActivitySlider activities={ACTIVITY_FEED} />
      </div>

      {/* Leaderboard */}
      <h4 className="fw-bold text-center mb-4">Leaderboard</h4>
      <Leaderboard users={LEADERBOARD_DATA} />
    </div>
  );
};

export default HomePage;
