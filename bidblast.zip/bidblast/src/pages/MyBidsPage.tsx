// ==================== src/pages/MyBidsPage.tsx ====================
import React from 'react';
import { Container, Card, Button, Alert } from 'react-bootstrap';
import { FaGavel } from 'react-icons/fa';

const MyBidsPage: React.FC = () => {
  return (
    <Container className="fade-in">
      <Card className="shadow text-center py-5">
        <Card.Body>
          <div className="mb-4">
            <div 
              className="d-inline-flex align-items-center justify-content-center rounded-circle"
              style={{
                width: '120px',
                height: '120px',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
              }}
            >
              <FaGavel size={60} color="white" />
            </div>
          </div>
          <h2 className="fw-bold mb-3">My Bids</h2>
          <p className="text-muted mb-4">Your active and past bids will appear here</p>
          <Button variant="primary" size="lg">
            Browse Active Bids
          </Button>
        </Card.Body>
      </Card>

      <Alert variant="info" className="mt-4">
        <Alert.Heading>💡 Pro Tip</Alert.Heading>
        <p className="mb-0">
          Join multiple bids to increase your chances of winning! Track all your bids in one place.
        </p>
      </Alert>
    </Container>
  );
};

export default MyBidsPage;