// ==================== src/pages/LeaderboardPage.tsx ====================
import React from 'react';
import { Container, Alert } from 'react-bootstrap';
import Leaderboard from '../components/Leaderboard';
import { LEADERBOARD_DATA } from '../utils/mockData';

const LeaderboardPage: React.FC = () => {
  return (
    <Container className="fade-in">
      <div className="mb-4">
        <h2 className="fw-bold">Global Leaderboard</h2>
        <p className="text-muted">Top performers across all bids</p>
      </div>
      
      <Leaderboard users={LEADERBOARD_DATA} />

      <Alert variant="success" className="mt-4">
        <strong>🎉 Congratulations!</strong> You're in the top 50! Keep bidding to climb higher.
      </Alert>
    </Container>
  );
};

export default LeaderboardPage;